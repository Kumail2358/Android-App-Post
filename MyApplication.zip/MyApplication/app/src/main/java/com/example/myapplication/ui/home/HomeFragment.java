package com.example.myapplication.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.ApiInterface;
import com.example.myapplication.MainActivity;
import com.example.myapplication.PostPojo;
import com.example.myapplication.R;
import com.example.myapplication.RetrofitInstance;
import com.example.myapplication.databinding.FragmentHomeBinding;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    ApiInterface apiInterface;
    RecyclerView recyclerView;
//    List<MyModel> myModelList;
//    CustomAdapter customAdapter;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

//        final TextView textView = binding.textHome;
//        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
//        displayItems();
        apiInterface = RetrofitInstance.getRetrofit().create(ApiInterface.class);
        apiInterface.getposts().enqueue(new Callback<List<PostPojo>>() {
            @Override
            public void onResponse(Call<List<PostPojo>> call, Response<List<PostPojo>> response) {
                if(response.body().size()>0){
//                    Type listType = new TypeToken<List<PostPojo>>(){}.getType();
//                    List<PostPojo> yourList = new Gson().fromJson(response.toString(), listType);
//                    Array list =
//                    JsonObject post = new JsonObject().get(response.body().get(0).toString()).getAsJsonObject();
                    TextView shower = (TextView)getView().findViewById(R.id.shower);

//                    JSONObject obj = new JSONObject(response.body().toString());
                    String tex = "";
                    for(int i = 0; i<response.body().size(); i++){
                        tex += "Title: "+response.body().get(i).getTitle()+"\n";
                        tex += "Body: "+response.body().get(i).getBody()+"\n \n";
                    }
                    shower.setText(tex);
//
//                    JsonObject obj = new JsonObject(response.body().get(0).toString());
//                    Toast.makeText(MainActivity.this, response.body().toString(), Toast.LENGTH_LONG).show();
                }
                else{
//                    Toast.makeText(MainActivity.this, "List is Empty", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<List<PostPojo>> call, Throwable t) {
//                Toast.makeText(MainActivity.this, t.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void displayItems() {
//        recyclerView = getView().findViewById(R.id.recycler);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1));
//        myModelList = new ArrayList<>();
//        myModelList.add(new MyModel("Some Title", "This is the Content"));
//        myModelList.add(new MyModel("Some Title", "This is the Content"));
//        myModelList.add(new MyModel("Some Title", "This is the Content"));
//        myModelList.add(new MyModel("Some Title", "This is the Content"));
//        myModelList.add(new MyModel("Some Title", "This is the Content"));
//        myModelList.add(new MyModel("Some Title", "This is the Content"));
//        customAdapter = new CustomAdapter(getActivity(), myModelList);
//        recyclerView.setAdapter(customAdapter);
    }
}